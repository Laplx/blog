% idhour:输入checkin和profile表，已转化的hour小时表，输出各用户各小时段访问数表

function idhour=idhour(xin,xfi,hours)
    siz_xfi = size(xfi);
    k = 0;
    idhour = num2cell(zeros(siz_xfi(1),10));
    for id = 1:siz_xfi(1)
        k = k + 1;
        idfi = xfi(id,1);
        count_t = sortrows(tabulate(hours(xin(:,1)==idfi)),1,"ascend");
        if sum(count_t~=0) ~= 0
            count_t(end+1:6,2) = 0;
            idhour(k,:) = {idfi,count_t(1,2),count_t(2,2),count_t(3,2),count_t(4,2),count_t(5,2),count_t(6,2),xfi(id,4),xfi(id,5),xfi(id,6)};
        end
    end
    idhour([idhour{:,1}]==num2str(0),:) = [];
end
