% idven:输入checkin和profile表，输出各用户各类型地点访问数表

function idven=idven(xin,xfi)
    siz_xfi = size(xfi);
    k = 0;
    idven = num2cell(zeros(siz_xfi(1),16));
    for id = 1:siz_xfi(1)
        k = k + 1;
        idfi = xfi(id,1);
        vent_i = vent(xin(xin(:,1)==idfi,:));
        if sum([vent_i{:,3}]~=0) ~= 0
            idven(k,:) = {idfi,vent_i{:,3},xfi(id,4),xfi(id,5),xfi(id,6)};
        end
    end
    idven([idven{:,1}]==num2str(0),:) = [];
end