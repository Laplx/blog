% vent:输入checkin表，输出各类地点的访问数表

function vent = vent(xin)    
    venue = sortrows(tabulate(xin(:,4)),2,"descend");
    siz_venue = size(venue);
    vent = {
        "food",["restaurant","bar","cafe","diner","gastropub","deli","bakeries","joint","places","food"],0;
        "shop",["mall","shop","store","market"],0;
        "work",["office","work"],0;
        "travel",["station","airport","bus","train","taxi","lounge","platform"],0;
        "home",["home"],0;
        "entertain",["neibor","event","parks","garden","theater","movie","music","plaza","entertainment","club","festival"],0;
        "hotel",["hotel","pub"],0;
        "scene",["bridge","river","lake","road","counties","field","outdoor"],0;
        "building",["building","cities","hall","landmark","housing","starup"],0;
        "culture",["university","school","college","libra","galler","studio","museum","art","exhi"],0;
        "sport",["gym","stadium","play"],0;
        "life",["bank","phar","hospital","laun","church","service","docter"],0
        };
    for i = 1:siz_venue(1)
        for s = 1:12
            if contains(venue{i,1},vent{s,2},'IgnoreCase',true)
                vent{s,3} = vent{s,3} + venue{i,2};
            end
        end
    end
end
