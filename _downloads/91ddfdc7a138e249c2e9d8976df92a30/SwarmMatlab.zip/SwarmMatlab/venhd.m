% venhd: 输入checkin表和vent表（vent(checkin)），输出各类型地点打卡数与时间、日期的关联矩阵

function [xhour,xday,venh,vend]=venhd(xin,xvent)
    intime = datetime(xin(:,8),'InputFormat','yy-MM-dd HH:mm');
    xhour = fix(intime.Hour / 4) + 1;
    xday = weekday(intime);
    
    co_ven_h = zeros(12,6);
    for s = 1:12
        logic = contains(xin(:,4),xvent{s,2},'IgnoreCase',true);
        count_t = tabulate(xhour(logic));
        co_ven_h(s,count_t(:,1)) = count_t(:,2);
    end
    venh = co_ven_h;
    
    co_ven_d = zeros(12,7);
    for s = 1:12
        logic = contains(xin(:,4),xvent{s,2},'IgnoreCase',true);
        count_t = tabulate(xday(logic));
        co_ven_d(s,count_t(:,1)) = count_t(:,2);
    end
    vend = co_ven_d;
end
