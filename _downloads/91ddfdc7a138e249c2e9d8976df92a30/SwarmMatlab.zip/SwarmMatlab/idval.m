% idval: 输入checkin和profile表，输出各用户逐次打卡的时间间隔和空间间隔（单位：小时、千米）
% 运行较慢

function val = idval(xin,xfi)
    siz_xfi = size(xfi);
    val = num2cell(zeros(siz_xfi(1),3));
    sin = str2double(xin(:,6:7));
    tin = datetime(xin(:,8),'InputFormat','yy-MM-dd HH:mm');
    for id = 1:siz_xfi(1)
        idfi = xfi(id,1);
        val(id,1) = cellstr(idfi);
        val{id,2} = (diff(sin(xin(:,1)==idfi,1)).^2 + diff(sin(xin(:,1)==idfi,2)).^2).^0.5*6370*pi/180;
        val{id,3} = hours(-diff(tin(xin(:,1)==idfi,1)));
    end